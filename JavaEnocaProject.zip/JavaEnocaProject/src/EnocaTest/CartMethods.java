package EnocaTest;
public interface CartMethods
{

    void getCart();
    void emptyCart();
}
